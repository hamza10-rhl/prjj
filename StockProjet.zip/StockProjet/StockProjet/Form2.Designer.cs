﻿
namespace StockProjet
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.usernametxt = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.fullnametxt = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.passwordtxt = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.emailtxt = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.usergv = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.testproDataSet = new StockProjet.testproDataSet();
            this.testproDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.usergv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testproDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testproDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1177, 100);
            this.panel1.TabIndex = 0;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1149, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "X";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(493, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "Manage users";
            // 
            // usernametxt
            // 
            this.usernametxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.usernametxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.usernametxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.usernametxt.HintForeColor = System.Drawing.Color.Empty;
            this.usernametxt.HintText = "";
            this.usernametxt.isPassword = false;
            this.usernametxt.LineFocusedColor = System.Drawing.Color.Blue;
            this.usernametxt.LineIdleColor = System.Drawing.Color.Gray;
            this.usernametxt.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.usernametxt.LineThickness = 3;
            this.usernametxt.Location = new System.Drawing.Point(13, 121);
            this.usernametxt.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.usernametxt.Name = "usernametxt";
            this.usernametxt.Size = new System.Drawing.Size(387, 44);
            this.usernametxt.TabIndex = 1;
            this.usernametxt.Text = "UserName";
            this.usernametxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.usernametxt.Enter += new System.EventHandler(this.usernametxt_Enter);
            // 
            // fullnametxt
            // 
            this.fullnametxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.fullnametxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.fullnametxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.fullnametxt.HintForeColor = System.Drawing.Color.Empty;
            this.fullnametxt.HintText = "";
            this.fullnametxt.isPassword = false;
            this.fullnametxt.LineFocusedColor = System.Drawing.Color.Blue;
            this.fullnametxt.LineIdleColor = System.Drawing.Color.Gray;
            this.fullnametxt.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.fullnametxt.LineThickness = 3;
            this.fullnametxt.Location = new System.Drawing.Point(13, 198);
            this.fullnametxt.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.fullnametxt.Name = "fullnametxt";
            this.fullnametxt.Size = new System.Drawing.Size(387, 44);
            this.fullnametxt.TabIndex = 2;
            this.fullnametxt.Text = "FullName";
            this.fullnametxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.fullnametxt.Enter += new System.EventHandler(this.fullnametxt_Enter);
            // 
            // passwordtxt
            // 
            this.passwordtxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.passwordtxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.passwordtxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.passwordtxt.HintForeColor = System.Drawing.Color.Empty;
            this.passwordtxt.HintText = "";
            this.passwordtxt.isPassword = false;
            this.passwordtxt.LineFocusedColor = System.Drawing.Color.Blue;
            this.passwordtxt.LineIdleColor = System.Drawing.Color.Gray;
            this.passwordtxt.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.passwordtxt.LineThickness = 3;
            this.passwordtxt.Location = new System.Drawing.Point(13, 281);
            this.passwordtxt.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.passwordtxt.Name = "passwordtxt";
            this.passwordtxt.Size = new System.Drawing.Size(387, 44);
            this.passwordtxt.TabIndex = 3;
            this.passwordtxt.Text = "Password";
            this.passwordtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.passwordtxt.Enter += new System.EventHandler(this.passwordtxt_Enter);
            // 
            // emailtxt
            // 
            this.emailtxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.emailtxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.emailtxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.emailtxt.HintForeColor = System.Drawing.Color.Empty;
            this.emailtxt.HintText = "";
            this.emailtxt.isPassword = false;
            this.emailtxt.LineFocusedColor = System.Drawing.Color.Blue;
            this.emailtxt.LineIdleColor = System.Drawing.Color.Gray;
            this.emailtxt.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.emailtxt.LineThickness = 3;
            this.emailtxt.Location = new System.Drawing.Point(13, 359);
            this.emailtxt.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.emailtxt.Name = "emailtxt";
            this.emailtxt.Size = new System.Drawing.Size(387, 44);
            this.emailtxt.TabIndex = 4;
            this.emailtxt.Text = "Email";
            this.emailtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.emailtxt.Enter += new System.EventHandler(this.emailtxt_Enter);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 449);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 44);
            this.button1.TabIndex = 5;
            this.button1.Text = "Ajouter";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(147, 449);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(113, 44);
            this.button2.TabIndex = 6;
            this.button2.Text = "Edit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(287, 449);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(113, 44);
            this.button3.TabIndex = 7;
            this.button3.Text = "Supprimer";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(147, 530);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(113, 44);
            this.button4.TabIndex = 8;
            this.button4.Text = "Home";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // usergv
            // 
            this.usergv.AutoGenerateColumns = false;
            this.usergv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.usergv.DataSource = this.testproDataSetBindingSource;
            this.usergv.Location = new System.Drawing.Point(491, 167);
            this.usergv.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.usergv.Name = "usergv";
            this.usergv.RowHeadersWidth = 51;
            this.usergv.RowTemplate.Height = 24;
            this.usergv.Size = new System.Drawing.Size(604, 391);
            this.usergv.TabIndex = 9;
            this.usergv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.usergv_CellContentClick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 603);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1177, 100);
            this.panel2.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(725, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 38);
            this.label3.TabIndex = 11;
            this.label3.Text = "User List";
            // 
            // testproDataSet
            // 
            this.testproDataSet.DataSetName = "testproDataSet";
            this.testproDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // testproDataSetBindingSource
            // 
            this.testproDataSetBindingSource.DataSource = this.testproDataSet;
            this.testproDataSetBindingSource.Position = 0;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1177, 703);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.usergv);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.emailtxt);
            this.Controls.Add(this.passwordtxt);
            this.Controls.Add(this.fullnametxt);
            this.Controls.Add(this.usernametxt);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.usergv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testproDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testproDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox usernametxt;
        private Bunifu.Framework.UI.BunifuMaterialTextbox fullnametxt;
        private Bunifu.Framework.UI.BunifuMaterialTextbox passwordtxt;
        private Bunifu.Framework.UI.BunifuMaterialTextbox emailtxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridView usergv;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.BindingSource testproDataSetBindingSource;
        private testproDataSet testproDataSet;
    }
}